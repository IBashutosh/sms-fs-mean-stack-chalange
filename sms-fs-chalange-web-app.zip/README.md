# sms-fs-code-chalange
MEAN Stack chalages
-----------------------------
Steps to run APP-
1: Install MongoDB
2: Downloda sms-fs-code-chalange folder
3: Go to directory /sms-fs-rest-api-server
4: npm i
5: npm start
6: go to directory /sms-fs-chalange-web-app
7: npm i
8: npm start
